import './App.css';
import Product from './Component/Product';
import { Route, Routes } from 'react-router-dom';
import Header from './Component/Header';
import Jewelery from './Component/Jewelery';
import Productdetails from './Component/Productdetails';
import Mensclothing from './Component/Mensclothing';
import Womensclothing from'./Component/Womensclothing'
import Electronics from './Component/Electronics';
import Input from './Redux/Input';
import Display from './Redux/Display';
import Home from './Component/Home';

function App() {
  return (
    <div className="App">
      {/* <Header />

      <Routes>
        <Route path='/' element={<Product />}>
          <Route path='jewelery' element={<Jewelery />} />
          <Route path='menscloths' element={<Mensclothing />} />
          <Route path='womenscloths' element={<Womensclothing/>} />
          <Route path='electronics' element={<Electronics />} />
        </Route>
        <Route path='productdetails/:id' element={<Productdetails />}></Route>
      </Routes> */}
      <Input/>
      <Display/>
      {/* <Home/> */}
    </div>
  );
}

export default App;
