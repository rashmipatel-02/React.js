import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function Home() {

    const [state, setState] = useState([])

    useEffect(() => {
        fetch()
    }, [])

    async function fetch() {
        const response = await axios.get("http://localhost:3000/products")
        console.log(response.data);
        setState(response.data)
    }

    return (
        <div>
            <div>
                {
                    state.map((el, i) => {               
                        return <li>{el.name}</li>
                    })
                }
            </div>
        </div>

    )
}
