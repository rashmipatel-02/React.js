import React, { useState } from 'react'
import { useDispatch } from 'react-redux'
import { myAction } from './Action'
import './App.css';

export default function Input() {
    const [state, setState] = useState('')
    const dispatch = useDispatch()

    function addText(e) {
        setState(e.target.value)
    }

    function Submit() { 
        dispatch(myAction(state))
    }

    return (
        <div className="container">
            <input type="text" placeholder='Enter a text' onChange={addText} />
            <button onClick={Submit} style={{padding:"10px 20px"}}>ADD</button>
        </div>
    )
}
