let arr = []

export const myReducer = (state = arr, action) => {
    if (action.type == "ADD") {
        return state = [
            ...state, action.payload
        ]
    }
    else if (action.type == "DELETE") {
        const array = state.filter((el, i) => {
            return i !== action.payload
        })
        state = array
    }
    else if (action.type == "EDIT") {
        const { i, newValue } = action.payload;

        return state.map((el, index) => (index === i ? newValue : el))
    }
    return state
}
