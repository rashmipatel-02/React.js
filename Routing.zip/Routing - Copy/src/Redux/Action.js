export const myAction = (payload) => {
    return {
        type: "ADD",
        payload 
    }
}

export const deleteAction = (payload) => {
    return {
        type: "DELETE",
        payload
    }
}

export const editAction = (i, newValue) => {
    return {
        type: "EDIT",
        payload: { i, newValue }
    }
}