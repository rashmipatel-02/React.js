import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { deleteAction, editAction } from './Action'
import './App.css';


export default function Display() {
    const data = useSelector((store) => store)
    const dispatch = useDispatch()

    function Delete(i) {
        dispatch(deleteAction(i))
    }

    function Edit(index) {
        const newValue = prompt("Enter a NewText: ")
        if (newValue) {
            dispatch(editAction(index, newValue))
        }
    }

    return (
        <div className="container">
            <ul>
                {
                    data.map((el, i) => {
                        return (
                            <li key={i}>
                                {el}
                                <div>
                                    <button onClick={() => Delete(i)}>Delete</button>
                                    <button onClick={() => Edit(i)}>Edit</button>
                                </div>
                            </li>
                        )
                    })
                }
            </ul>
        </div>
    )
}
