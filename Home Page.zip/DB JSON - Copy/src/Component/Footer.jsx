import React from 'react'

export default function Footer() {
  return (
    <footer className="footer">

      <div className="foot-img">
        <div style={{zIndex:"999"}}>
          <img src="https://www.tatacliq.com/src/general/components/img/trustFrame.png" alt="" /><br />
        </div>
        <div style={{marginTop:"-13px"}}>
          <img src="https://www.tatacliq.com/src/general/components/img/Frame22222.svg" alt="" />
        </div>
      </div>

      <div className="footer-top">
        <div className="footer-section">
          <h4>Tata MarketPlace</h4>
          <ul>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Careers</a></li>
            <li><a href="#">Sell With Us</a></li>
            <li><a href="#">Terms of Use</a></li>
            <li><a href="#">Privacy Policy</a></li>
            <li><a href="#">Affiliates</a></li>
            <li><a href="#">Sitemap</a></li>
          </ul>
        </div>
        <div className="footer-section">
          <h4>Customer Service</h4>
          <ul>
            <li><a href="#">Shopping</a></li>
            <li><a href="#">Offers & Promotions</a></li>
            <li><a href="#">Payments</a></li>
            <li><a href="#">Cancellation</a></li>
            <li><a href="#">Returns & Refunds</a></li>
            <li><a href="#">CliQ And PIQ</a></li>
            <li><a href="#">Return To Store</a></li>
            <li><a href="#">Electronics Return Policy</a></li>
            <li><a href="#">Contact Us</a></li>
            <li><a href="#">Reviews Guidelines</a></li>
            <li><a href="#">Furniture Return Policy</a></li>
            <li><a href="#">Replacement Policy</a></li>
          </ul>
        </div>
        <div className="footer-section">
          <h4>My Tata CLiQ</h4>
          <ul>
            <li><a href="#">My Account</a></li>
            <li><a href="#">My Orders</a></li>
            <li><a href="#">My Shopping Bag</a></li>
            <li><a href="#">My Wishlist</a></li>
          </ul>
        </div>
        <div className="footer-section" style={{ width: "40%" }}>
          <h4>Tata CLiQ Offerings</h4>

          <div>
            <a href="#"> Watches for Men </a><span>|</span>
            <a href="#"> Campus Shoes </a><span>|</span>
            <a href="#"> Sandals for Men </a><span>|</span>
            <a href="#"> Sneakers for Men </a><span>|</span>
            <a href="#"> Reebok Shoes </a><span>|</span>
            <a href="#"> Cotton Kurtis </a><span>|</span>
            <a href="#"> Woodland Shoes </a><span>|</span>
            <a href="#"> Jumpsuits </a><span>|</span>
            <a href="#"> Allen Solly </a><span>|</span>
            <a href="#"> Sparx Shoes </a><span>|</span>
            <a href="#"> Gold Rings </a><span>|</span>
            <a href="#"> Formal Shoes for Men </a><span>|</span>
            <a href="#"> Sports Shoes for Men </a><span>|</span>
            <a href="#"> Wallets for Men </a><span>|</span>
            <a href="#"> Ladies Watches </a><span>|</span>
            <a href="#"> Trolley Bags </a><span>|</span>
            <a href="#"> Handbags for Women </a><span>|</span>
            <a href="#"> Sling Bags for Women </a><span>|</span>
            <a href="#"> Casual Shoes for Men </a><span>|</span>
            <a href="#"> Boots for Men </a><span>|</span>
            <a href="#"> Digital Watches </a><span>|</span>
            <a href="#"> Sonata Watches </a><span>|</span>
            <a href="#"> Sneakers for Women </a><span>|</span>
            <a href="#"> Running Shoes </a><span>|</span>
            <a href="#"> Puma Shoes </a><span>|</span>
            <a href="#"> Boots for Women </a><span>|</span>
            <a href="#"> Skechers </a><span>|</span>
            <a href="#"> Malabar Gold </a><span>|</span>
            <a href="#"> Fabindia </a><span>|</span>
            <a href="#"> Utsa </a><span>|</span>
            <a href="#"> Vark </a><span>|</span>
            <a href="#"> Gia </a><span>|</span>
            <a href="#"> LOV </a><span>|</span>
            <a href="#"> Sitemap </a><span>|</span>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <div className="footer-icons">
          <a href="#"><i className="fab fa-facebook-f"></i></a>
          <a href="#"><i className="fab fa-twitter"></i></a>
          <a href="#"><i className="fab fa-instagram"></i></a>
          <a href="#"><i className="fab fa-youtube"></i></a>
          <a href="#"><i className="fab fa-linkedin"></i></a>
        </div>
        <div className="footer-app-links">
          <a href="#"><i className="fab fa-apple"></i> Download App</a>
          <a href="#"><i className="fab fa-google-play"></i></a>
        </div>
        <p>&copy; 2024 Tata CLiQ | All rights reserved</p>
      </div>
    </footer>
  )
}