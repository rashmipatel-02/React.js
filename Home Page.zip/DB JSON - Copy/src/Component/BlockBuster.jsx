import React, { useEffect, useState } from 'react'
import axios from 'axios'
import './BlockBuster.css'

export default function BlockBuster() {
    const [state, setState] = useState([])

    useEffect(() => {
        fetch()
    }, [])

    async function fetch() {
        const response = await axios.get("http://localhost:3000/BlockBuster Deals")
        console.log(response.data);
        setState(response.data)
    }
    return (
        <div>
            <div className='d-flex justify-content-center my-4 mx-auto' style={{ width: "78%" }}>
                <img src="https://assets.tatacliq.com/medias/sys_master/images/51758350237726.jpg" alt="" style={{ width: "100%" }} />
            </div>
            <div className='block-buster d-flex justify-content-center flex-wrap'>
                {
                    state.map((el, i) => {
                        return <>
                            <div className='bb-div d-flex justify-content-center flex-wrap m-4'>
                                <img src={el.image1} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                                <img src={el.image2} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                                <img src={el.image3} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                                <img src={el.image4} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                            </div>
                        </>
                    })
                }
            </div>
            <div className='d-flex justify-content-center mb-4 mx-auto' style={{ width: "78%", marginTop: "40px" }}>
                <img src="https://assets.tatacliq.com/medias/sys_master/images/51795416580126.jpg" alt="" style={{ width: "100%" }} />
            </div>
        </div>
    )
}

