import React, { useEffect, useState, useRef } from 'react'
import Slider from "react-slick";
import axios from 'axios';

export default function Digiden() {
    let sliderRef = useRef(null);
    const next = () => {
      sliderRef.slickNext();
    };
    const previous = () => {
      sliderRef.slickPrev();
    };
  
    var settings = {
      infinite: true,
      speed: 500,
      slidesToShow: 4,
      slidesToScroll: 1,
      initialSlide: 0,
      arrows: false,
      responsive: [
        {
          breakpoint: 1024,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 3,
            infinite: true,
          }
        },
        {
          breakpoint: 600,
          settings: {
            slidesToShow: 2,
            slidesToScroll: 2,
            initialSlide: 2
          }
        },
        {
          breakpoint: 480,
          settings: {
            slidesToShow: 1,
            slidesToScroll: 1
          }
        }
      ]
    }
    const [state, setState] = useState([])
  
    useEffect(() => {
      fetch()
    }, [])
  
    async function fetch() {
      const response = await axios.get("http://localhost:3000/Digiden")
      console.log(response.data);
      setState(response.data)
    }
    return (
      <div className='mx-auto' style={{ width: "78%" }}>
  
        <div className='d-flex justify-content-center mb-5' >
          <img src="https://assets.tatacliq.com/medias/sys_master/images/51750926811166.jpg" alt="" style={{ width: "100%" }} />
        </div >
  
        <div className='seal-deal-container'>
          <div className='arrows'>
            <button className="button" onClick={previous} style={{ borderStartStartRadius: "20px", borderEndStartRadius: "20px", backgroundColor: "white", border: "none", padding: "5px 10px 8px", marginRight: "2.5px" }}>
              <img src="https://img.icons8.com/?size=20&id=pDJEQEz46i19&format=png&color=000000" alt="" />
            </button>
            <button className="button" onClick={next} style={{ borderEndEndRadius: "20px", borderStartEndRadius: "20px", backgroundColor: "white", border: "none", padding: "5px 10px 8px" }}>
              <img src="https://img.icons8.com/?size=20&id=DydnsatR799b&format=png&color=000000" alt="" />
            </button>
          </div>
          <Slider ref={slider => {
            sliderRef = slider;
          }}
            {...settings}>
            {
              state.map((el, i) => {
                return <>
                  <div className='seal-deal' style={{ width: "100%" }}>
                    <img src={el.image} alt="" className='seal-img m-2' style={{ width: "90%" }} />
                  </div>
                </>
              })
            }
          </Slider>
        </div>
      </div>
    )

}
