import React from 'react'
import Slider from "react-slick";

export default function HomeSlider() {
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  return (
    <div className='slider-container mt-5 pt-4'>
      <Slider {...settings} className='w-100 positon-relative'>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52675364782110.jpg" alt="" style={{ width: "100%" }} />
        </div>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52727295836190.jpg" alt="" style={{ width: "100%" }} />
        </div>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52727295901726.jpg" alt="" style={{ width: "100%" }} />
        </div>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52727295967262.jpg" alt="" style={{ width: "100%" }} />
        </div>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52727296229406.jpg" alt="" style={{ width: "100%" }} />
        </div>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52727296032798.jpg" alt="" style={{ width: "100%" }} />
        </div>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52727296098334.jpg" alt="" style={{ width: "100%" }} />
        </div>
        <div>
          <img src="https://assets.tatacliq.com/medias/sys_master/images/52727296163870.jpg" alt="" style={{ width: "100%" }} />
        </div>
      </Slider>
    </div>
  )
}
