import React from 'react'
import './Nav.css';

export default function Nav() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark mb-4 ps-4 fixed-top" style={{ padding: "10px 0px", boxShadow: "0 4px 12px 0 rgba(0, 0, 0, .05)" }}>
                <div className="container-fluid">
                    <a className="navbar-brand ms-5" href="#"><img src="https://www.tatacliq.com/src/general/components/img/group.svg" alt="" style={{ width: "70px" }} /></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ms-5 mb-2 mb-lg-0" style={{ gap: "20px", fontWeight: "500" }}>
                            <li className="nav-item ms-5">
                                <a className="nav-link text-white" aria-current="page" href="#">Categories<img src="https://img.icons8.com/?size=30&id=85123&format=png&color=FFFFFF" alt="" />
                                </a>
                            </li>
                            <li className="nav-item me-4">
                                <a className="nav-link text-white" href="#">Brands<img src="https://img.icons8.com/?size=30&id=85123&format=png&color=FFFFFF" alt="" /></a>
                            </li>
                        </ul>

                        {/* searchbar */}
                        <div class="searchbar">
                            <i className="fa-solid fa-magnifying-glass"></i>
                            <input type="text" name="" id="search" placeholder="Search for categories" />
                        </div>

                        <div className='mx-2 d-flex align-items-center justify-content-center text-center'>
                            <div style={{ margin: "0px 15px" }}>
                                <img src="https://img.icons8.com/?size=25&id=16076&format=png&color=FFFFFF" alt="wishlist icon" />

                            </div>
                            <div style={{ margin: "0px 15px" }}>
                                <img src="https://img.icons8.com/?size=25&id=LXnBlSV2VPew&format=png&color=FFFFFF" alt="shopping-bag icon" />

                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        </div>
    )
}
