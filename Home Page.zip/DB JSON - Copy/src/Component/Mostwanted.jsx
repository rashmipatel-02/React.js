import React, { useEffect, useState, useRef } from 'react'
import Slider from "react-slick";
import axios from 'axios';

export default function Mostwanted() {
    let sliderRef = useRef(null);
    const next = () => {
        sliderRef.slickNext();
    };
    const previous = () => {
        sliderRef.slickPrev();
    };

    var settings = {
        infinite: true,
        speed: 500,
        slidesToShow: 4,
        slidesToScroll: 1,
        initialSlide: 0,
        arrows: false,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    }
    const [state, setState] = useState([])

    useEffect(() => {
        fetch()
    }, [])

    async function fetch() {
        const response = await axios.get("http://localhost:3000/Mostwanted")
        console.log(response.data);
        setState(response.data)
    }
    return (
        <div>
            <div className='d-flex justify-content-center my-4 mx-auto' style={{ width: "78%" }}>
                <img src="https://assets.tatacliq.com/medias/sys_master/images/51750926483486.jpg" alt="" style={{ width: "100%" }} />
            </div>
            <div className='block-buster d-flex justify-content-center flex-wrap'>
                {
                    state.map((el, i) => {
                        return <>
                            <div className='bb-div d-flex justify-content-center flex-wrap m-4'>
                                <img src={el.image1} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                                <img src={el.image2} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                                <img src={el.image3} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                                <img src={el.image4} alt="" className='bb-img m-2' style={{ height: "350px" }} />
                            </div>
                        </>
                    })
                }
            </div>
        </div>
    )

}
