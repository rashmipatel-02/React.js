import React, { useEffect, useState } from 'react'
import axios from 'axios'

export default function DiscountCoupen() {
    const [state, setState] = useState([])

    useEffect(() => {
        fetch()
    }, [])

    async function fetch() {
        const response = await axios.get("http://localhost:3000/DiscountCoupan")
        console.log(response.data);
        setState(response.data)
    }
    return (
        <div>
            <div className='dis-coupen d-flex justify-content-center flex-column items-center align-items-center flex-sm-row'>
                {
                    state.map((el, i) => {
                        return <>
                            <div className='dis-div'>
                                <img src={el.image} alt="" className='dis-img m-2' />
                            </div>
                        </>
                    })
                }
            </div>
        </div>
    )
}
