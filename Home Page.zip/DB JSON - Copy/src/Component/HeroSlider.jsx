import React, { useEffect, useState } from 'react'
import './HeroSlider.css';
import Slider from "react-slick";
import axios from 'axios';


export default function HeroSlider() {
    const settings = {
        dots: true,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        // speed: 000,
        autoplaySpeed: 3000,
    };
    const [state, setState] = useState([])

    useEffect(() => {
        fetch()
    }, [])

    async function fetch() {
        const response = await axios.get("http://localhost:3000/Heroslider")
        console.log(response.data);
        setState(response.data)
    }
    return (
        <div>
            <div className='slider-container_hero'>
                <Slider {...settings}>
                    {
                        state.map((el, i) => {
                            return <>
                                <div>
                                    <img src={el.image} alt="" className='hero_img'/>
                                </div>
                            </>
                        })
                    }
                </Slider>
            </div>
        </div >
    )
}
