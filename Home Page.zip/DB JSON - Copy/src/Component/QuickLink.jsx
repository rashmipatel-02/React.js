import React, { useEffect, useState } from 'react'
import axios from 'axios'
import './QuickLink.css'

export default function QuickLink() {
    const [state, setState] = useState([])

    useEffect(() => {
        fetch()
    }, [])

    async function fetch() {
        const response = await axios.get("http://localhost:3000/home")
        console.log(response.data);
        setState(response.data)
    }
    return (
        <div>

            <div className='quick-link'>
                {
                    state.map((el, i) => {
                        return <>
                            <div className='quick-link-div'>
                                <img src={el.image} alt="" className='quick-link-img' />
                            </div>
                        </>
                    })
                }
            </div>

        </div>
    )
}


