import React from 'react'
import Nav from '../Component/Nav'
import HomeSlider from '../Component/HomeSlider'
import QuickLink from '../Component/QuickLink'
import Westside from '../Component/Westside'
import HeroSlider from '../Component/HeroSlider'
import DiscountCoupen from '../Component/DiscountCoupen'
import BlockBuster from '../Component/BlockBuster'
import SealtheDeal1 from '../Component/SealtheDeal1'
import SealtheDeal2 from '../Component/SealtheDeal2'
import IndiFinds from '../Component/IndiFinds'
import Trending from '../Component/Trending'
import Mustwear from '../Component/Mustwear'
import Bringhome from '../Component/Bringhome'
import Digiden from '../Component/Digiden'
import Ticktalk from '../Component/Ticktalk'
import Mostwanted from '../Component/Mostwanted'
import Brandbargains from '../Component/Brandbargains'
import Footer from '../Component/Footer'

export default function Home() {
    return (
        <div>
            <Nav />
            {/* <HomeSlider /> */}
            <HeroSlider/>
            <QuickLink />
            <Westside />
            <DiscountCoupen/>
            <BlockBuster/>
            <SealtheDeal1/>
            <SealtheDeal2/>
            <IndiFinds/>
            <Trending/>
            <Mustwear/>
            <Bringhome/>
            <Digiden/>
            <Ticktalk/>
            <Mostwanted/>
            <Brandbargains/>
            <Footer/>
        </div>
    )
}
