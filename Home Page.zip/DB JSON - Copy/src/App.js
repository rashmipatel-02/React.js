import './App.css';
import Home from './Main_page/Home';

function App() {
  return (
    <div className="App">
      <Home/>
    </div>
  );
}

export default App;
