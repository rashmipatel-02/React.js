// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyCwu8hmDD_3KqUG_MMRuY5azn0YaPGJ8V4",
    authDomain: "fir-ec788.firebaseapp.com",
    databaseURL: "https://fir-ec788-default-rtdb.firebaseio.com",
    projectId: "fir-ec788",
    storageBucket: "fir-ec788.appspot.com",
    messagingSenderId: "812503863759",
    appId: "1:812503863759:web:247d27565a7781e2c242ba"
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);
