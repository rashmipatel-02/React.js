const initialState = {
    movies: [],
    editmovie: null,
  };
  
  const myReducer = (state = initialState, action) => {
    if (action.type === 'SET_MOVIE') {
      return {
        ...state,
        movies: action.payload,
      };
    } else if (action.type === 'ADD_MOVIE') {
      return {
        ...state,
        movies: [...state.movies, action.payload],
      };
    } else if (action.type === 'UPDATE_MOVIE') {
      return {
        ...state,
        movies: state.movies.map(product =>
          product.id === action.payload.id ? action.payload : product
        ),
      };
    } else if (action.type === 'DELETE_MOVIE') {
      return {
        ...state,
        movies: state.movies.filter(product => product.id !== action.payload),
      };
    } else if (action.type === 'SET_EDIT_MOVIE') {
      return {
        ...state,
        editmovie: action.payload,
      };
    } else if (action.type === 'CLEAR_EDIT_MOVIE') {
      return {
        ...state,
        editmovies: null,
      };
    } else {
      return state;
    }
  };
  
  export default myReducer;