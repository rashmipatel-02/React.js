export const setMovies= (products) => ({
    type: 'SET_MOVIE',
    payload: products,
});

export const addMovie = (product) => ({
    type: 'ADD_MOVIE',
    payload: product,
});

export const updateMovie = (product) => ({
    type: 'UPDATE_MOVIE',
    payload: product,
});

export const deleteMovie = (id) => ({
    type: 'DELETE_MOVIE',
    payload: id,
});

export const setEditMovie = (product) => ({
    type: 'SET_EDIT_MOVIE',
    payload: product,
});

export const clearEditMovie = () => ({
    type: 'CLEAR_EDIT_MOVIE',
});