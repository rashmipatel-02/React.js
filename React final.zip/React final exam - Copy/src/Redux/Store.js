
import { legacy_createStore as createstore } from "redux";
import myReducer from "./Reducer";

export const store = createstore(myReducer)

