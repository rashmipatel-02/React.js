import React, { useContext } from 'react'
import Login from './Login'
import { myContext } from './context'
import MovieForm from './MovieSearch'


export default function Auth() {
    const state = useContext(myContext)

    return (
        <div>
            {
                state.isLogged ? <MovieForm /> : <Login />
            }
        </div>
    )
}
