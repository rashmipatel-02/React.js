import React, { useState } from 'react'
import { createUserWithEmailAndPassword, getAuth } from "firebase/auth";
import { app } from '../Firebase';

const auth = getAuth(app);
export default function SignUp() {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    function signup() {
        createUserWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                alert("success")
            })
            .catch((error) => {
               console.log(error)
            });

    }
    return (
        <div>
            <h2>Sign Up</h2>
            <input type="email" placeholder='Enter Email' onChange={(e) => setEmail(e.target.value)} />
            <input type="password" placeholder='Enter Password' onChange={(e) => setPassword(e.target.value)} />
            <button onClick={signup}>Sign Up</button>
        </div>
    )
}
