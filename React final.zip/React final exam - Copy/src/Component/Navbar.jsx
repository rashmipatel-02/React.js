import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { myContext } from './context';

export default function Navbar() {
  const { state, logged } = useContext(myContext);

  const logout = () => {
    logged({
      user: "User",
      isLogged: false
    });
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light border-bottom">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">Movie</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/">Home</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/movies">Movies</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/search">Movie Search</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/contact">Contact</Link>
            </li>
          </ul>

          <div className="d-flex align-items-center ms-auto">
            {state.isLogged ? (
              <>
                <span className="text-dark me-3">User: {state.user}</span>
                <button onClick={logout} className="btn btn-outline-dark">Log Out</button>
              </>
            ) : (
              <>
                <Link to="/signup">
                  <button className="btn btn-outline-success me-2">Sign Up</button>
                </Link>
                <Link to="/login">
                  <button className="btn btn-outline-dark">Login</button>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
