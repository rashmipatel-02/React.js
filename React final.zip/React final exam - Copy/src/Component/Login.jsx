import React, { useContext, useState } from 'react'
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";
import { myContext } from './context';
import { app } from '../Firebase';

const auth = getAuth(app);

export default function Login() {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")
    const { logged } = useContext(myContext)

    function login() {
        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                alert("Login Successful")
                logged({
                    user: userCredential.user.email,
                    isLogged: true
                })
            })
            .catch((error) => {
                console.log(error)
            });
    }
    return (
        <div>
            <h2>Login</h2>
            <input type="email" placeholder='Enter Email' onChange={(e) => setEmail(e.target.value)} />
            <input type="password" placeholder='Enter Password' onChange={(e) => setPassword(e.target.value)} />
            <button onClick={login}>Login</button>
        </div>
    )
}
