import { createContext } from "react";

export const myContext = createContext()