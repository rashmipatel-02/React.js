import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';

export default function MovieDetails() {
    const { id } = useParams();
    const [movie, setMovie] = useState(null);

    useEffect(() => {
        Moviedetails();
    }, [id]);

    async function Moviedetails() {
        try {
            const response = await axios.get(`http://localhost:3002/Movies/${id}`);
            setMovie(response.data);
        } catch (error) {
            console.error("Error fetching movie details:", error);
        }
    }

    if (!movie) {
        return (
            <div className="container mt-5 text-center">
                <h4>Loading movie details...</h4>
            </div>
        );
    }

    return (
        <div className="container mt-5">
            <div className="row">
                <div className="col-md-4 mb-4">
                    <div className="card border-0">
                        <img
                            src={movie.poster_url}
                            alt={movie.title}
                            className="card-img img-fluid"
                            style={{ height: '500px', objectFit: 'cover' }}
                        />
                    </div>
                </div>
                <div className="col-md-8 text-start">
                    <div className="card border-0">
                        <div className="card-body">
                            <h2 className="card-title">{movie.title}</h2>
                            <p className="card-text"><strong>Director:</strong> {movie.director}</p>
                            <p className="card-text"><strong>Release Date:</strong> {movie.release_date}</p>
                            <p className="card-text"><strong>Rating:</strong> {movie.rating}</p>
                            <p className="card-text"><strong>Genre:</strong> {movie.genre}</p>
                            <p className="card-text"><strong>Cast:</strong> {movie.cast.join(', ')}</p>
                            <p className="card-text"><strong>Description:</strong> {movie.description}</p>
                            <Link to="/movies" className="btn btn-primary mt-3">Back to Movie List</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
