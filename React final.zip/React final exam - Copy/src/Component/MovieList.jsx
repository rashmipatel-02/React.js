import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

export default function MovieList() {
    const [state, setState] = useState([]);
    const [ascending, setAscending] = useState(true);
    const [search, setSearch] = useState('');

    useEffect(() => {
        fetchMovies();
    }, []);

    async function fetchMovies() {
        try {
            const response = await axios.get("http://localhost:3002/Movies");
            console.log(response.data);
            setState(response.data);
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    }

    function handleSort() {
        const sortedData = [...state].sort((a, b) => {
            if (ascending) {
                return a.title > b.title ? 1 : -1;
            } else {
                return a.title < b.title ? 1 : -1;
            }
        });
        setState(sortedData);
        setAscending(!ascending);
    }

    function handleSearch(e) {
        setSearch(e.target.value);
    }

    const filteredMovies = state.filter((el) =>
        el.title.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="container mt-5">
            <h2 className="text-center mb-4">Movie List</h2>

            <div className="d-flex justify-content-between mb-4">
                <input
                    type="search"
                    placeholder="Search by Title..."
                    value={search}
                    onChange={handleSearch}
                    className="form-control"
                    style={{ maxWidth: '940px' }}
                />
                <button
                    onClick={handleSort}
                    className="btn btn-primary"
                >
                    Sort by {ascending ? "Descending" : "Ascending"}
                </button>
            </div>

            <div className="row">
                {filteredMovies.length > 0 ? (
                    filteredMovies.map((el) => (
                        <div key={el.id} className="col-md-3 mb-4">
                            <Link to={`/Details/${el.id}`} className="text-decoration-none">
                                <div className="card h-100">
                                    <img 
                                        src={el.poster_url} 
                                        alt={el.title} 
                                        className="img-fluid img-thumbnail" 
                                        style={{ height: '320px', objectFit: 'cover' }} 
                                    />
                                    <div className="card-body text-center">
                                        <h5 className="card-title">{el.title}</h5>
                                    </div>
                                </div>
                            </Link>
                        </div>
                    ))
                ) : (
                    <div className="col-12 text-center">
                        <h4>Movie Not Found</h4>
                    </div>
                )}
            </div>
        </div>
    );
}
