import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addMovie, clearEditMovie, deleteMovie, setEditMovie, setMovies, updateMovie } from '../Redux/Action';

export default function MovieForm() {
  const dispatch = useDispatch();
  const { movies, editMovie } = useSelector(store => store);
  const [newMovie, setNewMovie] = useState({
    id: '',
    title: '',
    description: '',
    poster_url: '',
    director: '',
    release_date: '',
    rating: '',
    genre: '',
    cast: []
  });

  useEffect(() => {
    FetchData();
  }, []);

  const FetchData = async () => {
    try {
      const response = await axios.get('http://localhost:3002/Movies');
      dispatch(setMovies(response.data));
    } catch (error) {
      console.error('Error fetching data', error);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewMovie({
      ...newMovie,
      [name]: value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (editMovie) {
        if (newMovie.id !== editMovie.id) {
          await axios.delete(`http://localhost:3002/Movies/${editMovie.id}`);
          await axios.post('http://localhost:3002/Movies', newMovie);
          dispatch(deleteMovie(editMovie.id));
          dispatch(addMovie(newMovie));
        } else {
          await axios.put(`http://localhost:3002/Movies/${editMovie.id}`, newMovie);
          dispatch(updateMovie(newMovie));
        }
        dispatch(clearEditMovie());
      } else {
        await axios.post('http://localhost:3002/Movies', newMovie);
        dispatch(addMovie(newMovie));
      }
      setNewMovie({
        id: '',
        title: '',
        description: '',
        poster_url: '',
        director: '',
        release_date: '',
        rating: '',
        genre: '',
        cast: []
      });
    } catch (error) {
      console.error('Error adding or updating movie', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:3002/Movies/${id}`);
      dispatch(deleteMovie(id));
    } catch (error) {
      console.error('Error deleting movie', error);
    }
  };

  const handleUpdate = (data) => {
    setNewMovie(data);
    dispatch(setEditMovie(data));
  };

  return (
    <div className="container mt-4">
      <h1 className="text-center mb-4">Movie Form</h1>
      <form onSubmit={handleSubmit} className="form-horizontal">
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="id">Movie ID:</label>
          <div className="col-sm-10">
            <input type="text" name="id" placeholder="Movie ID" value={newMovie.id} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="title">Movie Title:</label>
          <div className="col-sm-10">
            <input type="text" name="title" placeholder="Movie Title" value={newMovie.title} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="description">Description:</label>
          <div className="col-sm-10">
            <input type="text" name="description" placeholder="Description" value={newMovie.description} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="poster_url">Poster URL:</label>
          <div className="col-sm-10">
            <input type="text" name="poster_url" placeholder="Poster URL" value={newMovie.poster_url} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="director">Director:</label>
          <div className="col-sm-10">
            <input type="text" name="director" placeholder="Director" value={newMovie.director} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="release_date">Release Date:</label>
          <div className="col-sm-10">
            <input type="text" name="release_date" placeholder="Release Date" value={newMovie.release_date} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="rating">Rating:</label>
          <div className="col-sm-10">
            <input type="text" name="rating" placeholder="Rating" value={newMovie.rating} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="genre">Genre:</label>
          <div className="col-sm-10">
            <input type="text" name="genre" placeholder="Genre" value={newMovie.genre} onChange={handleChange} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <label className="col-sm-2 col-form-label mt-2" htmlFor="cast">Cast:</label>
          <div className="col-sm-10">
            <input type="text" name="cast" placeholder="Cast (comma separated)" value={newMovie.cast.join(', ')} onChange={(e) => setNewMovie({ ...newMovie, cast: e.target.value.split(',').map(item => item.trim()) })} className="form-control" />
          </div>
        </div>
        <div className="form-group row">
          <div className="col-sm-12 mt-3 text-center">
            <button type="submit" className="btn btn-primary">{editMovie ? 'Edit' : 'Add'}</button>
          </div>
        </div>
      </form>
      <h2 className="text-center mt-4">Movies</h2>
      <div className="row">
        {movies.map((item) => (
          <div className="col-lg-3 col-md-6 mb-4" key={item.id}>
            <div className="card h-100">
              <img src={item.poster_url} className="img-fluid img-thumbnail" alt={item.title} style={{height:"350px"}}/>
              <div className="card-body">
                <h5 className="card-title">{item.title}</h5>
                <button onClick={() => handleUpdate(item)} className="btn btn-success me-2">Update</button>
                <button onClick={() => handleDelete(item.id)} className="btn btn-danger">Delete</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
