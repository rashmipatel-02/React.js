import { Route, Routes } from 'react-router-dom';
import './App.css';
import Home from './Component/Home';
import Navbar from './Component/Navbar';
import MovieList from './Component/MovieList';
import MovieDetails from './Component/MovieDetails';
import MovieForm from './Component/MovieSearch';
import { useState } from 'react';
import { myContext } from './Component/context';
import SignUp from './Component/SignUp';
import Login from './Component/Login';
import PrivateRoute from './Component/PrivateRoute';


function App() {
  const [state, setState] = useState({
    user: "User",
    isLogged: false
  })

  function logged(data) {
    setState(data)
  }
  return (
    <div className="App">
      <myContext.Provider value={{ state, logged }}>
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/movies" element={<MovieList />} />
          <Route path="/search" element={<PrivateRoute element={<MovieForm/>} />} />
          <Route path="Details/:id" element={<MovieDetails />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
        </Routes>
      </myContext.Provider>
    </div>
  );
}

export default App;
