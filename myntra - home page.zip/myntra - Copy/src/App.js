import './App.css';
import Navbar from './Component/Navbar';
import Herosection from './Component/Herosection';
import Brands1 from './Component/Brands1';
import Brands2 from './Component/Brands2';
import Category from './Component/Category';
import Footer from './Component/Footer';
import Product from './Component/Product';
import { Route, Routes } from 'react-router-dom';
import Header from './Component/Header';
import Jewelery from './Component/Jewelery';
import Productdetails from './Component/Productdetails';
import Input from './Redux/Input';
import Display from './Redux/Display';

function App() {
  return (
    <div className="App">
      {/* <Navbar/>
      <Herosection/>
      <Brands1/>
      <Brands2/>
      <Category/>
      <Footer/>
      <Product/> */}
      {/* <Header />

      <Routes>
        <Route path='/' element={<Herosection />}></Route>
        <Route path='/brands1' element={<Brands1 />}></Route>
        <Route path='/brands2' element={<Brands2 />}></Route>
        <Route path='/category' element={<Category />}></Route>
        <Route path='/product' element={<Product />}>
          <Route path='jewelery' element={<Jewelery/>}></Route>
        </Route>
        <Route path='productdetails/:id' element={<Productdetails/>}></Route>
      </Routes> */}
      <Input />
      <Display />
    </div>
  );
}

export default App;
