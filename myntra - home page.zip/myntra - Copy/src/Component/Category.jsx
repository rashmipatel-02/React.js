import React from 'react'

export default function Category() {
    return (
        <div>
            <h2 className="text-start py-5 mt-5 slider-title">SHOP BY CATEGORY</h2>

            <div className="c-row1">
                <div className="col-2 m-3">
                    <img src="https://img.faballey.com/images/Product/ILL00379Z/1.jpg" alt="" />
                    <h6 className='my-1'>Womens's Ethnic Wear</h6>
                    <h4 className='my-1 fw-bold'>50-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://cdn.luxe.digital/media/2019/09/12084906/casual-dress-code-men-street-style-luxe-digital-1.jpg" alt="" />
                    <h6 className='my-1'>WFH Casual Wear</h6>
                    <h4 className='my-1 fw-bold'>40-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://www.newtheoryclothing.com/cdn/shop/files/1_15be3c0e-66d7-4068-a7d0-7cc5463caa16.png?v=1690888546&width=1000" alt="" />
                    <h6 className='my-1'>Men's Activewear</h6>
                    <h4 className='my-1 fw-bold'>30-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://hummel.net.in/cdn/shop/files/3430084-2321.png?v=1708681041&width=533" alt="" />
                    <h6 className='my-1'>Women's Activewear</h6>
                    <h4 className='my-1 fw-bold'>30-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/dpr_1.5,q_60,w_400,c_limit,fl_progressive/assets/images/16334738/2024/6/6/4cceed5b-8860-419f-93aa-a29632016aae1717648777196-Blissclub-Women-Black-Super-Stretchy--High-Waisted-The-Ultim-11.jpg" alt="" />
                    <h6 className='my-1'>Western Wear</h6>
                    <h4 className='my-1 fw-bold'>40-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://colin-sports.com/templates/images/cat3.jpg" alt="" />
                    <h6 className='my-1'>Sportswear</h6>
                    <h4 className='my-1 fw-bold'>30-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
            </div>
            <div className="c-row1">
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/21381390/2023/1/2/99379ceb-5cac-437a-9e60-d4ecb48ceec81672650275673Nightsuits1.jpg" alt="" />
                    <h6 className='my-1'>Loungewear</h6>
                    <h4 className='my-1 fw-bold'>30-60% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://cdn.luxe.digital/media/2019/09/12084906/casual-dress-code-men-street-style-luxe-digital-1.jpg" alt="" />
                    <h6 className='my-1'>WFH Casual Wear</h6>
                    <h4 className='my-1 fw-bold'>40-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://www.newtheoryclothing.com/cdn/shop/files/1_15be3c0e-66d7-4068-a7d0-7cc5463caa16.png?v=1690888546&width=1000" alt="" />
                    <h6 className='my-1'>Men's Activewear</h6>
                    <h4 className='my-1 fw-bold'>30-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/h_1440,q_100,w_1080/v1/assets/images/2470493/2018/3/13/11520942558562-Timex-Unisex-Set-of-2-His--Her-Watches-1021520942558308-1.jpg" alt="" />
                    <h6 className='my-1'>Watches</h6>
                    <h4 className='my-1 fw-bold'>UP TO 80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://menhood.in/cdn/shop/files/Essential-Package.jpg?v=1711540362&width=1946" alt="" style={{objectFit:"cover"}}/>
                    <h6 className='my-1'>Grooming</h6>
                    <h4 className='my-1 fw-bold'>UP TO 60% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://dailytimes.com.pk/assets/uploads/2021/04/11/beauty-decorative-cosmetics-makeup-brushes-set-and-royalty-free-image-930934354-1565213062.jpg" alt="" style={{objectFit:"cover"}}/>
                    <h6 className='my-1'>Beauty & Makeup</h6>
                    <h4 className='my-1 fw-bold'>UP TO 60% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
            </div>
            <div className="c-row1">
                <div className="col-2 m-3">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2YSbAUhfmz4HZWgUJ-kmCTY5cNvT4ta0d0_bB-jPdSlAaq6hEtEEfnM8eESMSMVH6RHo&usqp=CAU" alt="" />
                    <h6 className='my-1'>Kids Wear</h6>
                    <h4 className='my-1 fw-bold'>50-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/dpr_1.5,q_60,w_400,c_limit,fl_progressive/assets/images/24592346/2023/8/22/95005a4c-074f-43b2-968e-bb060794a2ed1692713208695RedTapeMenWhiteColourblockedPUSkateShoes1.jpg" alt="" />
                    <h6 className='my-1'>Men's Footwear</h6>
                    <h4 className='my-1 fw-bold'>50-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/19626598/2022/11/9/bce86da2-1c1a-4f67-b77e-4a65c2a919881667985306223-Sherrif-Shoes-Purple-Party-Block-Pumps-with-Bows-92116679853-11.jpg" alt="" style={{objectFit:"cover"}}/>
                    <h6 className='my-1'>Women's Footwear</h6>
                    <h4 className='my-1 fw-bold'>40-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/29839935/2024/5/30/a90c25a0-ed77-4d0e-833a-a3994b2dbc691717052403848AccessoryGiftSet1.jpg" alt="" />
                    <h6 className='my-1'>Bag,Belts & Wallets</h6>
                    <h4 className='my-1 fw-bold'>40-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://www.shutterstock.com/image-photo/business-team-work-office-group-600nw-2277682451.jpg" alt="" style={{objectFit:"cover"}}/>
                    <h6 className='my-1'>Office Wear</h6>
                    <h4 className='my-1 fw-bold'>40-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://shaadiwish.com/blog/wp-content/uploads/2021/10/pastel-kurta-pajama.jpg" alt="" />
                    <h6 className='my-1'>Men's Ethnic Wear</h6>
                    <h4 className='my-1 fw-bold'>UP TO 60% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
            </div>
            <div className="c-row1">
                <div className="col-2 m-3">
                    <img src="https://m.media-amazon.com/images/I/71fMumdJU3L._AC_UF894,1000_QL80_.jpg" alt="" />
                    <h6 className='my-1'>Home Decor</h6>
                    <h4 className='my-1 fw-bold'>40-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDAUGYxJ_JtdRiNBJupMZ21DhslcvTjw0RPFX9tTA0yNQkB0nitSFBW0mhCJ97-vo19ho&usqp=CAU" alt="" style={{objectFit:"cover"}}/>
                    <h6 className='my-1'>Handbags</h6>
                    <h4 className='my-1 fw-bold'>40-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://i.rtings.com/assets/pages/nyS7u7mM/best-home-bluetooth-speakers-20230901-2-medium.jpg?format=auto" alt="" style={{objectFit:"cover",objectPosition:"center"}}/>
                    <h6 className='my-1'>Men's Activewear</h6>
                    <h4 className='my-1 fw-bold'>30-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/17550846/2023/6/15/7c3ade16-6ec5-4975-bc73-f4e01ffba2db1686819761298-Saraf-RS-Jewellery-Rose-Gold-Plated-White-AD-Studded-Jewelle-13.jpg" alt="" style={{objectFit:"cover"}}/>
                    <h6 className='my-1'>Jewellery</h6>
                    <h4 className='my-1 fw-bold'>UP TO 80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://www.penningtons.com/on/demandware.static/-/Sites-Penningtons-master-catalog/default/dw61e3dbc8/images/large/penningtons_481015_1_0.webp" alt="" style={{objectFit:"cover"}}/>
                    <h6 className='my-1'>Size-Inclusive Styles</h6>
                    <h4 className='my-1 fw-bold'>UP TO 60% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://imageio.forbes.com/specials-images/imageserve/64bfec87a74d88011cb8ced8/page-featured-1/960x0.jpg?height=947&width=711&fit=bounds" alt="" />
                    <h6 className='my-1'>Inclusive Styles</h6>
                    <h4 className='my-1 fw-bold'>UP TO 60% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
            </div>
            <div className="c-row1">
                <div className="col-2 m-3">
                    <img src="https://www.gonoise.com/cdn/shop/files/image_32_082349c8-edab-477b-ab72-28d6a843d559.png?v=1712732740" alt="" />
                    <h6 className='my-1'>Watches & Wearables</h6>
                    <h4 className='my-1 fw-bold'>UP TO 80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://images.meesho.com/images/products/230857376/ruoe7_512.webp" alt="" />
                    <h6 className='my-1'>Sleepwear</h6>
                    <h4 className='my-1 fw-bold'>30-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://www.roddandgunn.com/dw/image/v2/BBRS_PRD/on/demandware.static/-/Sites-roddandgunn-master-catalog/default/dwd1227ff2/images/008754/BP1500_MIDNIGHT_FT_LGE.jpg?sw=458&sh=565&sm=fit" alt="" />
                    <h6 className='my-1'>Workwear</h6>
                    <h4 className='my-1 fw-bold'>40-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://down-ph.img.susercontent.com/file/sg-11134201-7qvf4-lhzwp338vryq36" alt="" />
                    <h6 className='my-1'>Eyewear</h6>
                    <h4 className='my-1 fw-bold'>UP TO 80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://sourcingjournal.com/wp-content/uploads/2022/10/argent.jpg?w=240" alt="" />
                    <h6 className='my-1'>Workwear</h6>
                    <h4 className='my-1 fw-bold'>40-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/dpr_1.5,q_60,w_400,c_limit,fl_progressive/assets/images/13116364/2021/7/27/df294d75-087c-4f85-bebb-096e2db5ebdd1627373150915TokyoTalkiesWomenBlueWhiteStripedLoungeTop1.jpg" alt="" />
                    <h6 className='my-1'>Casual Styles</h6>
                    <h4 className='my-1 fw-bold'>40-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
            </div>
            <div className="c-row1">
                <div className="col-2 m-3">
                    <img src="https://staranddaisy.in/wp-content/uploads/2024/02/kids-school-bags-Genius-Scribble_Blue_4.jpg" alt="" />
                    <h6 className='my-1'>Bags & Backpacks</h6>
                    <h4 className='my-1 fw-bold'>30-80% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://www.jiomart.com/images/product/original/rvf365rvfa/vip-red-medium-check-in-suitcase-68-cm-product-images-orvf365rvfa-p600527804-0-202304141526.jpg?im=Resize=(360,360)" alt="" />
                    <h6 className='my-1'>Trolly & Luggage Bags</h6>
                    <h4 className='my-1 fw-bold'>30-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
                <div className="col-2 m-3">
                    <img src="https://assets.myntassets.com/w_412,q_60,dpr_2,fl_progressive/assets/images/17543212/2023/2/17/1c299824-af5f-4025-83a3-1a1da0b9bb711676633518533-Puma-Men-Black--Red-Softride-Slide-Massage-Sliders-416167663-6.jpg" alt="" />
                    <h6 className='my-1'>Flip-Flops</h6>
                    <h4 className='my-1 fw-bold'>30-70% off</h4>
                    <h6 className='my-1'>Shop Now</h6>
                </div>
            </div>

            <img src="https://assets.myntassets.com/f_webp,w_980,c_limit,fl_progressive,dpr_2.0/assets/images/2024/6/29/152cc50f-dd16-4f20-93e8-1416fe0f06c51719638676181-App-Install-Banner.jpg" alt="" style={{width:"100%",margin:"15px 0px 30px"}}/>
        </div>
    )
}
