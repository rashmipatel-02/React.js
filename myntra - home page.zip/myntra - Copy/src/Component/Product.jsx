import React from 'react'
import { Link, Outlet } from 'react-router-dom'

export default function Product() {
  return (
    <div>
      <nav>
        <Link to='jewelery'>Jewelery</Link>
        <Link to='electronic'>Electronic</Link>
        <Link to='mensclothing'>Mensclothing</Link>
        <Link to='womensclothing'>Womensclothing</Link>
      </nav>
      <div>
        <Outlet />
      </div>
    </div>
  )
}
