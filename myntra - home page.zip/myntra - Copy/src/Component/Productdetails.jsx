import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'

export default function Productdetails() {
    const [state, setState] = useState([])
    const { id } = useParams()

    useEffect(() => {
        Fetch()
    }, [])

    function Fetch() {
        fetch(`https://fakestoreapi.com/products/${id}`)
            .then(res => res.json())
            .then((data) => {
                setState(data)
                console.log(data);
            })
    }

    return (
        <div>
            <h1>Productdetails</h1>
            <div>
                <img src={state.image} alt="" />
                <p>{state.title}</p>
            </div>

        </div>
    )
}
