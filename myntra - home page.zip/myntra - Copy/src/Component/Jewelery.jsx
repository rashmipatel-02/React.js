import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

export default function Jewelery() {

    const [state, setState] = useState([])

    useEffect(() => {
        Fetch()
    }, [])

    function Fetch() {
        fetch('https://fakestoreapi.com/products/category/jewelery')
            .then(res => res.json())
            .then((data) => {
                setState(data)
                console.log(data);
            })
    }

    return (
        <div>
            <h1>Jewelery</h1>
            <div>
                {
                    state.map((el, i) => {
                        return (
                            <>
                                <img src={el.image} alt="" />
                                <Link to={`/productdetails/${el.id}`}>{el.title}</Link>
                            </>
                        )
                    })
                }
            </div>
        </div>
    )
}
