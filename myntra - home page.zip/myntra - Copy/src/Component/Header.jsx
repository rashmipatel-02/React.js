import React from 'react'
import { Link } from 'react-router-dom'

export default function Header() {
    return (
        <div>
            <Link to='/'>Herosection</Link>
            <Link to='/brands1'>Brands1</Link>
            <Link to='/brands2'>Brands2</Link>
            <Link to='/category'>Category</Link>
            <Link to='/product'>Product</Link>
        </div>
    )
}
