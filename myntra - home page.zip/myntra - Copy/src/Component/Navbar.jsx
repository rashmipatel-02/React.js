import React from 'react'

export default function Navbar() {
    return (
        <div>
            <nav className="navbar navbar-expand-lg bg-body mb-4 ps-4 fixed-top" style={{ padding: "10px 0px", boxShadow: "0 4px 12px 0 rgba(0, 0, 0, .05)" }}>
                <div className="container-fluid">
                    <a className="navbar-brand" href="#"><img src="https://www.freelogovectors.net/wp-content/uploads/2023/01/myntra-logo-freelogovectors.net_.png" alt="" style={{ width: "70px" }} /></a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav me-auto mb-2 mb-lg-0" style={{ fontSize: "13px", gap: "20px", fontWeight: "700" }}>
                            <li className="nav-item">
                                <a className="nav-link" aria-current="page" href="#" style={{ color: "#282c3f" }}>MEN</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#" style={{ color: "#282c3f" }}>WOMEN</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#" style={{ color: "#282c3f" }}>KIDS</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#" style={{ color: "#282c3f" }}>HOME & LIVING</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#" style={{ color: "#282c3f" }}>BEAUTY</a>
                            </li>
                            <li className="nav-item">
                                <a className="nav-link" href="#" style={{ color: "#282c3f" }}>STUDIO <sup style={{ color: "#FF3F6C" }}>NEW</sup> </a>
                            </li>

                        </ul>

                        {/* searchbar */}
                        <div class="searchbar">
                            <i className="fa-solid fa-magnifying-glass"></i>
                            <input type="text" name="" id="search" placeholder="Search for products brands & more " />
                        </div>

                        <div className='mx-2 d-flex align-items-center justify-content-center text-center' style={{ marginTop: "10px", marginBottom: "-8px" }}>
                            <div style={{ margin: "0px 15px" }}>
                                <img src="https://pic.onlinewebfonts.com/thumbnails/icons_403715.svg" alt="user icon" style={{ height: "18px" }} />
                                <p style={{ fontSize: "11px", fontWeight: "700" }}>Profile</p>
                            </div>
                            <div style={{ margin: "0px 15px" }}>
                                <img src="https://pic.onlinewebfonts.com/thumbnails/icons_126692.svg" alt="wishlist icon" style={{ height: "18px" }} />
                                <p style={{ fontSize: "11px", fontWeight: "700" }}>wishlist</p>
                            </div>
                            <div style={{ margin: "0px 15px" }}>
                                <img src="https://pic.onlinewebfonts.com/thumbnails/icons_334009.svg" alt="shopping-bag icon" style={{ height: "18px" }} />
                                <p style={{ fontSize: "11px", fontWeight: "700" }}>Bag</p>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>

        </div>
    )
}
