import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { deleteAction, editAction } from './Action'

export default function Display() {

    const data = useSelector((store) => { return store })
    const dispatch = useDispatch()

    function Delete(index) {
        dispatch(deleteAction(index))
    }

    function Edit(index) {
        const editText = prompt("Enter your text: ", data[index])
        if (editText !== null && editText.trim() !== '') {
            dispatch(editAction(index, editText))
        }
    }

    return (
        <div>
            {
                data.map((el, i) => {
                    return <li>
                        {el}
                        <button onClick={() => Delete(i)}>Delete</button>
                        <button onClick={() => Edit(i)}>Edit</button>
                    </li>
                })
            }
        </div>
    )
}
