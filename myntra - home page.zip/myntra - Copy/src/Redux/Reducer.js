let arr = [];

export const myReducer = (state = arr, action) => {
    if (action.type == "ADD") {
        return state = [
            ...state, action.payload
        ]
    }
    else if (action.type == "DELETE") {
        // const newstate = [...state]
        // newstate.splice(action.payload, 1)
        // return newstate

        const array = state.filter((el, i) => {
            return i !== action.payload
        })
        state = array
    }
    else if (action.type == "EDIT") {
        return state.map((item, index) => {
            if (index === action.payload.index) {
                return action.payload.newText
            }
            return item
        })
    }
    return state;
}
