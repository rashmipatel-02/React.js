import React from 'react'
import { useState } from 'react'
import { useDispatch } from 'react-redux'
import { myAction } from './Action'

export default function Input() {

    const [state, setState] = useState('')
    const dispatch = useDispatch()

    function handleText(e) {
        setState(e.target.value)
    }

    function handleSubmit() {
        dispatch(myAction(state))
    }

    return (
        <div>

            <input type="text" onChange={handleText} />
            <button onClick={handleSubmit}>Click</button>

        </div>
    )
}
