export const myAction = (payload) => {
    return {
        type: "ADD",
        payload
    }
}

export const deleteAction = (index) => {
    return {
        type: "DELETE",
        payload: index
    }
}

export const editAction = (index,newText) => {
    return {
        type: "EDIT",
        payload: { index, newText }
    }
}